const ws = new WebSocket("ws://localhost:8000/ws");

ws.onmessage = function(event){
    const data = JSON.parse(event.data);
    if(data.frame){
        document.getElementById('video').src = 'data:image/jpeg;base64,'+data.frame;
    }
    if(data.bpm){
        document.getElementById('bpm').innerText = "Heart Rate: "+data.bpm+" bpm";
    }
    if(data.alerts){
        const alertsDiv = document.getElementById('alerts');
        alertsDiv.innerHTML = '';
        data.alerts.forEach(a=>{
            const div = document.createElement('div');
            div.className = 'alert '+a.color;
            div.innerText = a.msg;
            alertsDiv.appendChild(div);
        });
    }
}
