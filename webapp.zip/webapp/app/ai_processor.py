import cv2
import mediapipe as mp
import numpy as np
from .utils import eye_aspect_ratio, bandpass_filter
from .alerts import AlertManager

LEFT_EYE_IDX = [33, 160, 158, 133, 153, 144]
RIGHT_EYE_IDX = [362, 385, 387, 263, 373, 380]

class AIProcessor:
    def __init__(self):
        self.face_mesh = mp.solutions.face_mesh.FaceMesh(static_image_mode=False, max_num_faces=1)
        self.green_buf = []
        self.buffer_size = 300
        self.hr_hist = []
        self.HR_SMOOTH = 5
        self.closed_frames = 0
        self.face_missing = 0
        self.alert_manager = AlertManager()
        self.abnormal_counter = 0

    def calculate_heart_rate(self, fs=30):
        if len(self.green_buf) < fs*8:
            return None
        filtered = bandpass_filter(np.array(self.green_buf), 0.7, 4.0, fs, order=6)
        fft = np.abs(np.fft.rfft(filtered))
        freqs = np.fft.rfftfreq(len(filtered), d=1.0/fs)
        valid = np.where((freqs>=0.8) & (freqs<=3.0))
        valid_freqs = freqs[valid]
        if len(valid_freqs)==0: return None
        peak = np.argmax(fft[valid])
        bpm = int(valid_freqs[peak]*60)
        return bpm if 40<=bpm<=160 else None

    def detect_face_redness(self, frame, landmarks, w, h):
        nose = landmarks.landmark[1]
        cx, cy = int(nose.x*w), int(nose.y*h)
        x1, y1 = max(cx-15,0), max(cy-15,0)
        x2, y2 = min(cx+15,w), min(cy+15,h)
        roi = frame[y1:y2, x1:x2]
        if roi.size==0: return 0
        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        lower1, upper1 = np.array([0,70,50]), np.array([10,255,255])
        lower2, upper2 = np.array([170,70,50]), np.array([180,255,255])
        mask = cv2.inRange(hsv, lower1, upper1) + cv2.inRange(hsv, lower2, upper2)
        return np.sum(mask)/(roi.size/3)

    def process_frame(self, frame):
        h, w = frame.shape[:2]
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.face_mesh.process(rgb)
        bpm_display = None

        if results.multi_face_landmarks:
            self.face_missing = 0
            lm = results.multi_face_landmarks[0]
            # EAR
            ear = (eye_aspect_ratio(lm, LEFT_EYE_IDX, w, h) + 
                   eye_aspect_ratio(lm, RIGHT_EYE_IDX, w, h))/2
            if ear < 0.25:
                self.closed_frames += 1
            else:
                self.closed_frames = 0
            if self.closed_frames >= 20 and self.alert_manager.can_trigger("drowsy"):
                self.alert_manager.add_alert("drowsy", "DROWSINESS ALERT!", "red")

            # Redness
            redness = self.detect_face_redness(frame, lm, w, h)
            if redness > 0.35 and self.alert_manager.can_trigger("injury"):
                self.alert_manager.add_alert("injury", "Possible Injury Detected!", "red")

            # Heart-rate
            lf, rf = lm.landmark[70], lm.landmark[300]
            x1, y1, x2, y2 = int(lf.x*w), int(lf.y*h), int(rf.x*w), int(rf.y*h)+20
            roi = frame[y1:y2, x1:x2]
            if roi.size > 0:
                g_mean = np.mean(roi[:,:,1])
                self.green_buf.append(g_mean)
                if len(self.green_buf) > self.buffer_size:
                    self.green_buf.pop(0)
                bpm = self.calculate_heart_rate()
                if bpm:
                    self.hr_hist.append(bpm)
                    if len(self.hr_hist) > self.HR_SMOOTH: self.hr_hist.pop(0)
                    bpm_display = int(sum(self.hr_hist)/len(self.hr_hist))
                    if (bpm_display<50 or bpm_display>120):
                        self.abnormal_counter += 1
                    else:
                        self.abnormal_counter = 0
                    if self.abnormal_counter >= 3 and self.alert_manager.can_trigger("cardiac"):
                        self.alert_manager.add_alert("cardiac", "Abnormal Heart Rate!", "red")
        else:
            self.face_missing += 1
            if self.face_missing > 50 and self.alert_manager.can_trigger("noface"):
                self.alert_manager.add_alert("noface", "No Face Detected!", "red")

        return frame, bpm_display, self.alert_manager.get_active_alerts()
