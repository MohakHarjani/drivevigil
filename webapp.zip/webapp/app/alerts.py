import time

COOLDOWN_TIME = 5.0
ALERT_DURATION = 3.0

class AlertManager:
    def __init__(self):
        self.active_alerts = {}
        self.alert_cooldowns = {}

    def add_alert(self, key, msg, color):
        now = time.time()
        self.active_alerts[key] = (msg, color, now)
        self.alert_cooldowns[key] = now

    def get_active_alerts(self):
        now = time.time()
        expired = [k for k,(msg,c,t) in self.active_alerts.items() if now - t > ALERT_DURATION]
        for k in expired:
            self.active_alerts.pop(k)
        return [(msg, color) for msg, color, t in self.active_alerts.values()]

    def can_trigger(self, key):
        now = time.time()
        last = self.alert_cooldowns.get(key, 0)
        return now - last > COOLDOWN_TIME
