from fastapi import FastAPI, WebSocket
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import cv2
import base64
import queue
import time
from .ai_processor import AIProcessor
from .voice_listener import start_listener

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

cap = cv2.VideoCapture(0)
processor = AIProcessor()
command_queue = queue.Queue()
start_listener(command_queue)

awaiting_conf = False
conf_start = None
help_count = 0

@app.get("/")
async def get_index():
    return templates.TemplateResponse("index.html", {"request": {}})

def gen_frames():
    global awaiting_conf, conf_start, help_count
    while True:
        ret, frame = cap.read()
        if not ret: continue
        frame = cv2.flip(frame, 1)
        frame, bpm, alerts = processor.process_frame(frame)

        # Voice commands
        now = time.time()
        while not command_queue.empty():
            cmd = command_queue.get().lower()
            if awaiting_conf:
                if "yes" in cmd or "ok" in cmd:
                    processor.alert_manager.add_alert("help_yes", "User confirmed OK. Taking action.", "green")
                    awaiting_conf = False
                elif "no" in cmd:
                    processor.alert_manager.add_alert("help_no", "Help confirmed! Calling emergency.", "red")
                    awaiting_conf = False
            elif "help" in cmd:
                help_count += 1
                if help_count >=3:
                    processor.alert_manager.add_alert("help_auto", "Multiple HELP requests! Auto alert.", "red")
                elif processor.alert_manager.can_trigger("help"):
                    processor.alert_manager.add_alert("help", "Are you alright? Say Yes or No.", "yellow")
                    awaiting_conf, conf_start = True, now

        # Confirmation timeout
        if awaiting_conf and conf_start and now - conf_start > 15:
            processor.alert_manager.add_alert("help_timeout", "No confirmation received. Help cancelled.", "red")
            awaiting_conf = False

        _, buffer = cv2.imencode('.jpg', frame)
        frame_b64 = base64.b64encode(buffer).decode()
        yield frame_b64, bpm, processor.alert_manager.get_active_alerts()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    for frame_b64, bpm, alerts in gen_frames():
        data = {
            "frame": frame_b64,
            "alerts": [{"msg": m, "color": c} for m,c in alerts],
            "bpm": bpm
        }
        await websocket.send_json(data)
