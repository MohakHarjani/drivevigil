import numpy as np
from scipy.signal import butter, lfilter

# --- Bandpass Filter ---
def butter_bandpass(lowcut, highcut, fs, order=5):
    nyq = 0.5 * fs
    low, high = lowcut / nyq, highcut / nyq
    b, a = butter(order, [low, high], btype="band")
    return b, a

def bandpass_filter(data, lowcut=0.7, highcut=4.0, fs=30, order=5):
    b, a = butter_bandpass(lowcut, highcut, fs, order=order)
    return lfilter(b, a, data)

# --- EAR computation ---
def eye_aspect_ratio(landmarks, eye_indices, w, h):
    coords = [(int(landmarks.landmark[i].x * w),
               int(landmarks.landmark[i].y * h)) for i in eye_indices]
    A = np.linalg.norm(np.array(coords[1]) - np.array(coords[5]))
    B = np.linalg.norm(np.array(coords[2]) - np.array(coords[4]))
    C = np.linalg.norm(np.array(coords[0]) - np.array(coords[3]))
    return (A + B) / (2.0 * C)
