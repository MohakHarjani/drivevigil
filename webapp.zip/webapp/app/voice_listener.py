import threading
import queue
import speech_recognition as sr

def voice_command_listener(command_queue):
    rec = sr.Recognizer()
    mic = sr.Microphone()
    with mic as src:
        rec.adjust_for_ambient_noise(src)
    while True:
        try:
            with mic as src:
                audio = rec.listen(src, phrase_time_limit=3)
            cmd = rec.recognize_google(audio).lower()
            if cmd:
                command_queue.put(cmd)
        except Exception:
            pass

def start_listener(command_queue):
    threading.Thread(target=voice_command_listener, args=(command_queue,), daemon=True).start()
